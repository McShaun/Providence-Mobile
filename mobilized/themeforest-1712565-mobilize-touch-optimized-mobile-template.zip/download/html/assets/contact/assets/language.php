<?php
$language->attention_please		= 'Validation Errors:';
$language->name_required		= 'First name is required.';
$language->lastname_required	= 'Last name is required.';
$language->email_required		= 'Email is required.';
$language->email_valid			= 'Please enter a valid email address.';
$language->phone_required		= 'Phone number is required.';
$language->subject_required		= 'Subject is required.';
$language->message_required		= 'Message is required.';
$language->areyouhuman_required	= 'Are you human field is required.';
$language->areyouhuman_valid	= 'Are you human result is wrong.';

$language->field_required		= 'Field required';
$language->name					= 'First Name:';
$language->lastname				= 'Last Name:';
$language->email				= 'Email:';
$language->phone				= 'Phone:';
$language->subject				= 'Subject:';
$language->message				= 'Message:';
$language->join_mailing_list	= 'Join our mailing lists:';
$language->yes_please			= 'Yes Please';
$language->no_thanks			= 'No Thanks';
$language->how_did_you_find_us	= 'How did you find us?:';
$language->are_you_human		= 'Are you human?';
$language->send_yourself		= 'Send yourself a copy:';
$language->cancel				= 'Cancel';
$language->submit				= 'Submit';
$language->back					= 'Back';
$language->done					= 'Done';
?>
