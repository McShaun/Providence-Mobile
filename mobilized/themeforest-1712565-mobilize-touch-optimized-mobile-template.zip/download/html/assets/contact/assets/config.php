<?php
// User Settings
$title						= 'Mobile Contact Form';			// Page Title
$email_header				= 'Mobile Contact Form';			// enter email header
$your_name					= 'Joe Somebody';					// enter your name
$send_to					= 'info@yourdomain.com';			// enter your email address
$reply_to					= '';								// leave blank to reply to destination address
$type						= 'html';							// or text
$charset					= 'utf-8';							// enter charset (default UTF-8)
$mailing_list				= 1;								// mailing list field: enable = 1, disable = 0
$how_you_found_us			= 1;								// how you found us field: enable = 1, disable = 0
$how_you_found_us_options	=	array(							// how you found us options
									"Google Search",
									"Bing Search",
									"TV",
									"Radio",
									"Magazine",
									"Word of Mouth"
								);
// End User Settings
?>